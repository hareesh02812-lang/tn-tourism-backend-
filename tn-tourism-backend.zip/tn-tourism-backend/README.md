# Tamil Nadu Tourism — Backend API

A Node.js/Express + MongoDB backend implementing the server side of the TN Tourism app.
This covers the parts of the spec that a backend can actually do: data modeling, search,
budget calculation, itinerary generation, auth, and reviews. It does **not** include the
mobile app UI, live map tiles, or a production voice/translation pipeline — those are
client-side or third-party-service concerns layered on top of these APIs (see "What's real
vs. what needs a key" below).

## Quick start

```bash
npm install
cp .env.example .env        # then fill in MONGO_URI, JWT_SECRET at minimum
npm run seed                 # loads sample districts/places/hotels/food into MongoDB
npm run dev                  # or `npm start`
```

Requires a running MongoDB instance (local `mongod`, Docker, or Atlas — just point
`MONGO_URI` at it).

## Project structure

```
server.js                  Express app entrypoint
src/
  config/db.js              Mongoose connection
  models/                   District, Place, Hotel, FoodSpot, User, Review, Trip
  routes/                   One file per resource, mounted under /api/*
  controllers/               Request handlers
  services/
    budgetService.js         Trip cost estimation math (real, works offline)
    aiItineraryService.js    Rule-based itinerary engine + optional Claude call
    weatherService.js        OpenWeatherMap integration
  middleware/                JWT auth, error handling
  seed/                      Sample data for 6 real TN destinations + seed script
```

## API reference

| Method | Endpoint | Purpose |
|---|---|---|
| GET  | `/api/health` | Liveness check |
| POST | `/api/auth/signup` | Create account |
| POST | `/api/auth/login` | Get JWT |
| GET  | `/api/auth/me` | Current user profile + saved items (auth) |
| GET  | `/api/places?category=&district=&lat=&lng=&maxDistanceKm=&sort=` | Browse/filter places |
| GET  | `/api/places/:id` | Full profile: history, visiting info, crowd pattern, nearby hotels/food/places |
| POST | `/api/places/:id/save` | Save to favourites (auth) |
| GET  | `/api/districts` | List districts |
| GET  | `/api/districts/:id` | District detail + its places |
| GET  | `/api/hotels?district=&tier=&maxPrice=` | Browse hotels |
| GET  | `/api/food?district=&vegType=` | Browse food spots |
| GET  | `/api/search?q=` | Typo-tolerant search across places/hotels/food/districts, with a "did you mean" suggestion |
| GET  | `/api/search/autocomplete?q=` | Autocomplete suggestions |
| POST | `/api/budget/calculate` | `{ placeId, days, people, startLocation, transportMode, hotelTier }` → full cost breakdown |
| POST | `/api/budget/suggest` | `{ maxBudgetINR, days, people, startLocation, themes }` → recommended + cheaper/pricier alternatives |
| POST | `/api/ai/itinerary` | `{ startLocation, budgetINR, days, people, themes, narrate }` → generated day plan + cost breakdown |
| GET  | `/api/weather?lat=&lng=` | Live current weather (needs `OPENWEATHER_API_KEY`) |
| GET  | `/api/weather/forecast?lat=&lng=` | 24h forecast |
| POST | `/api/reviews` | Submit a rating/review (auth, goes into `pending` status) |
| PATCH| `/api/reviews/:id/approve` | Approve a review, rolls it into the target's aggregate rating |
| GET  | `/api/reviews/:targetType/:targetId` | Approved reviews for a place/hotel/foodSpot |

### Example: the spec's own budget-planner example

```bash
curl -X POST localhost:5000/api/ai/itinerary \
  -H "Content-Type: application/json" \
  -d '{
    "startLocation": { "label": "Theni", "lat": 10.0104, "lng": 77.4768 },
    "budgetINR": 3000,
    "days": 1,
    "people": 1
  }'
```

Returns a chosen destination, activities, and a cost breakdown (travel / hotel / food /
attractions / other), all tagged `"dataQuality": "estimated"`.

## What's real vs. what needs a key

Per the spec's own "Data Reliability" section (never invent live data), this backend is
explicit about which numbers are computed estimates and which are live:

- **Works fully offline, no keys needed:** search + typo correction, budget calculator math,
  place/hotel/food browsing & filtering, the rule-based itinerary engine, auth, reviews/ratings.
- **Needs `OPENWEATHER_API_KEY`:** `/api/weather*` — without it, the endpoint returns
  `{ available: false, dataQuality: "not_available" }` rather than fake weather.
- **Needs `GOOGLE_MAPS_API_KEY`:** not yet wired into a route in this build — the budget
  service currently estimates distance with a haversine formula; swap in the Directions API
  in `budgetService.js` for real road distance/time.
- **Needs `ANTHROPIC_API_KEY`:** optional — pass `"narrate": true` to `/api/ai/itinerary` to
  have Claude turn the computed itinerary into a friendlier written explanation. Without a
  key, you still get the full structured itinerary from the rule engine.
- **Crowd levels** (`Place.crowdPattern`) are modeled as `low/moderate/high` per day/time-slot
  with a `source` tag (`verified` / `live` / `estimated` / `user_reports`) — seed data ships
  empty; populate this from real footfall/analytics data before treating it as live.
- **Offline mode, voice assistant, multilingual translation, and the interactive map** are
  primarily client-side features (the mobile app caches API responses locally, calls a
  speech-to-text/TTS SDK, and calls a translation API). This backend supports them by keeping
  responses small/cacheable and by storing `nameLocal: { ta, hi }` fields on District/Place —
  wire up device TTS/translation SDKs or a service like Google Cloud Translation on the client
  or in a thin proxy route.

## Extending

- Add real destinations: extend `src/seed/seedData.js` or build an admin-only `POST /api/places`
  route (omitted here — add `requireAuth` + a role check before exposing writes publicly).
- Add more languages: `nameLocal` on District/Place already supports arbitrary keys.
- Swap the rule-based itinerary for a multi-day planner: `aiItineraryService.js` currently
  returns a single-stop, single-day plan; extend the scoring loop to chain 2-3 nearby places
  per day within budget.
