require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');

const connectDB = require('./src/config/db');
const { errorHandler, notFound } = require('./src/middleware/errorHandler');

const authRoutes = require('./src/routes/auth');
const placeRoutes = require('./src/routes/places');
const districtRoutes = require('./src/routes/districts');
const hotelRoutes = require('./src/routes/hotels');
const foodRoutes = require('./src/routes/food');
const searchRoutes = require('./src/routes/search');
const budgetRoutes = require('./src/routes/budget');
const aiRoutes = require('./src/routes/ai');
const weatherRoutes = require('./src/routes/weather');
const reviewRoutes = require('./src/routes/reviews');

const app = express();

app.use(helmet());
app.use(cors());
app.use(express.json({ limit: '2mb' }));
app.use(morgan('dev'));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, max: 300 })); // 300 req / 15 min per IP

app.get('/api/health', (req, res) => res.json({ status: 'ok', service: 'tn-tourism-backend' }));

app.use('/api/auth', authRoutes);
app.use('/api/places', placeRoutes);
app.use('/api/districts', districtRoutes);
app.use('/api/hotels', hotelRoutes);
app.use('/api/food', foodRoutes);
app.use('/api/search', searchRoutes);
app.use('/api/budget', budgetRoutes);
app.use('/api/ai', aiRoutes);
app.use('/api/weather', weatherRoutes);
app.use('/api/reviews', reviewRoutes);

app.use(notFound);
app.use(errorHandler);

const PORT = process.env.PORT || 5000;

async function start() {
  await connectDB();
  app.listen(PORT, () => console.log(`[server] listening on http://localhost:${PORT}`));
}

start();

module.exports = app;
