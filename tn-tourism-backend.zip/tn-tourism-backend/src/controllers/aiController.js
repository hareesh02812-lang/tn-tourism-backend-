const { generateRuleBasedItinerary, generateWithClaude } = require('../services/aiItineraryService');

/**
 * POST /api/ai/itinerary
 * Body example matching the spec's own example:
 * { "startLocation": { "label": "Theni", "lat": 10.0104, "lng": 77.4768 }, "budgetINR": 3000, "days": 1, "people": 1 }
 */
async function itinerary(req, res, next) {
  try {
    const { startLocation, budgetINR, days, people, themes, prompt } = req.body;
    if (!budgetINR) return res.status(400).json({ error: 'budgetINR is required' });

    const ruleBased = await generateRuleBasedItinerary({
      startLocation,
      budgetINR: Number(budgetINR),
      days: days ? Number(days) : 1,
      people: people ? Number(people) : 1,
      themes
    });

    if (ruleBased.error) return res.status(404).json(ruleBased);

    // If the client wants a friendlier narration and a Claude key is configured, use it.
    const useClaude = req.body.narrate === true;
    const result = useClaude
      ? await generateWithClaude(prompt || `Plan a trip with budget ₹${budgetINR}`, ruleBased)
      : ruleBased;

    res.json(result);
  } catch (err) {
    next(err);
  }
}

module.exports = { itinerary };
