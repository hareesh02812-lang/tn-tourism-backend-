const Review = require('../models/Review');
const Place = require('../models/Place');
const Hotel = require('../models/Hotel');
const FoodSpot = require('../models/FoodSpot');

const MODEL_MAP = { place: 'Place', hotel: 'Hotel', foodSpot: 'FoodSpot' };
const COLLECTION_MAP = { place: Place, hotel: Hotel, foodSpot: FoodSpot };

async function createReview(req, res, next) {
  try {
    const { targetType, targetId, stars, text, photos } = req.body;
    if (!MODEL_MAP[targetType] || !targetId || !stars) {
      return res.status(400).json({ error: 'targetType (place|hotel|foodSpot), targetId and stars are required' });
    }

    const review = await Review.create({
      user: req.user.id,
      targetType,
      target: targetId,
      targetType_model: MODEL_MAP[targetType],
      stars,
      text,
      photos,
      status: 'pending' // goes through moderation before counting toward official rating - spec section 20/21
    });

    res.status(201).json(review);
  } catch (err) {
    next(err);
  }
}

/** Admin/moderation endpoint: approve a review and roll it into the target's aggregate rating. */
async function approveReview(req, res, next) {
  try {
    const review = await Review.findById(req.params.id);
    if (!review) return res.status(404).json({ error: 'Review not found' });

    review.status = 'approved';
    await review.save();

    const Model = COLLECTION_MAP[review.targetType];
    const target = await Model.findById(review.target);
    if (target) {
      const newCount = target.rating.count + 1;
      const newAvg = (target.rating.avg * target.rating.count + review.stars) / newCount;
      target.rating = { avg: Math.round(newAvg * 10) / 10, count: newCount };
      await target.save();
    }

    res.json({ review, message: 'Review approved and rating updated' });
  } catch (err) {
    next(err);
  }
}

async function listReviewsForTarget(req, res, next) {
  try {
    const { targetType, targetId } = req.params;
    const reviews = await Review.find({ targetType, target: targetId, status: 'approved' })
      .populate('user', 'name')
      .sort('-createdAt');
    res.json(reviews);
  } catch (err) {
    next(err);
  }
}

module.exports = { createReview, approveReview, listReviewsForTarget };
