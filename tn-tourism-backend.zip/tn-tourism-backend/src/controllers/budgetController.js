const Place = require('../models/Place');
const { estimateTripCost, suggestDestinationsForBudget } = require('../services/budgetService');

/** POST /api/budget/calculate - explicit destination + trip params -> cost breakdown */
async function calculate(req, res, next) {
  try {
    const { placeId, days, people, startLocation, transportMode, hotelTier } = req.body;
    if (!placeId || !days || !people) {
      return res.status(400).json({ error: 'placeId, days and people are required' });
    }
    const place = await Place.findById(placeId).lean();
    if (!place) return res.status(404).json({ error: 'Place not found' });

    const result = await estimateTripCost({
      place,
      days: Number(days),
      people: Number(people),
      startLocation,
      transportMode,
      hotelTierHint: hotelTier
    });
    res.json(result);
  } catch (err) {
    next(err);
  }
}

/** POST /api/budget/suggest - only a max budget -> recommended destinations (spec section 6) */
async function suggest(req, res, next) {
  try {
    const { maxBudgetINR, days, people, startLocation, themes } = req.body;
    if (!maxBudgetINR) return res.status(400).json({ error: 'maxBudgetINR is required' });

    const result = await suggestDestinationsForBudget({
      maxBudgetINR: Number(maxBudgetINR),
      days: days ? Number(days) : 1,
      people: people ? Number(people) : 1,
      startLocation,
      themes
    });
    res.json(result);
  } catch (err) {
    next(err);
  }
}

module.exports = { calculate, suggest };
