const { getLiveWeather, getForecast } = require('../services/weatherService');

async function current(req, res, next) {
  try {
    const { lat, lng } = req.query;
    if (!lat || !lng) return res.status(400).json({ error: 'lat and lng query params are required' });
    const data = await getLiveWeather({ lat: Number(lat), lng: Number(lng) });
    res.json(data);
  } catch (err) {
    next(err);
  }
}

async function forecast(req, res, next) {
  try {
    const { lat, lng } = req.query;
    if (!lat || !lng) return res.status(400).json({ error: 'lat and lng query params are required' });
    const data = await getForecast({ lat: Number(lat), lng: Number(lng) });
    res.json(data);
  } catch (err) {
    next(err);
  }
}

module.exports = { current, forecast };
