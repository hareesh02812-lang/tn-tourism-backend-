const Fuse = require('fuse.js');
const Place = require('../models/Place');
const Hotel = require('../models/Hotel');
const FoodSpot = require('../models/FoodSpot');
const District = require('../models/District');

/**
 * Typo-tolerant search (spec section 12: search must suggest corrected names
 * rather than returning nothing on a misspelling). Fuse.js does approximate
 * string matching so "Rameshwaram" / "Ramesvaram" still finds "Rameswaram".
 */
async function search(req, res, next) {
  try {
    const q = (req.query.q || '').trim();
    if (!q) return res.status(400).json({ error: 'q query param is required' });

    const [places, hotels, food, districts] = await Promise.all([
      Place.find().select('name category shortDescription district').lean(),
      Hotel.find().select('name tier district').lean(),
      FoodSpot.find().select('name specialties district').lean(),
      District.find().select('name region').lean()
    ]);

    const fuseOpts = { includeScore: true, threshold: 0.4, keys: ['name'] };

    const results = {
      places: new Fuse(places, fuseOpts).search(q).slice(0, 8).map((r) => ({ ...r.item, score: r.score, type: 'place' })),
      hotels: new Fuse(hotels, fuseOpts).search(q).slice(0, 8).map((r) => ({ ...r.item, score: r.score, type: 'hotel' })),
      food: new Fuse(food, { ...fuseOpts, keys: ['name', 'specialties'] })
        .search(q)
        .slice(0, 8)
        .map((r) => ({ ...r.item, score: r.score, type: 'food' })),
      districts: new Fuse(districts, fuseOpts).search(q).slice(0, 8).map((r) => ({ ...r.item, score: r.score, type: 'district' }))
    };

    const totalHits = results.places.length + results.hotels.length + results.food.length + results.districts.length;

    // Best-effort "did you mean" suggestion when nothing matched closely
    let suggestion = null;
    if (totalHits === 0) {
      const looseOpts = { includeScore: true, threshold: 0.6, keys: ['name'] };
      const loose = new Fuse([...places, ...hotels, ...food, ...districts], looseOpts).search(q);
      if (loose[0]) suggestion = loose[0].item.name;
    }

    res.json({ query: q, totalHits, results, suggestion });
  } catch (err) {
    next(err);
  }
}

async function autocomplete(req, res, next) {
  try {
    const q = (req.query.q || '').trim();
    if (!q) return res.json({ suggestions: [] });

    const [places, districts] = await Promise.all([
      Place.find().select('name').lean(),
      District.find().select('name').lean()
    ]);
    const fuse = new Fuse([...places, ...districts], { includeScore: true, threshold: 0.45, keys: ['name'] });
    const suggestions = fuse.search(q).slice(0, 6).map((r) => r.item.name);
    res.json({ suggestions });
  } catch (err) {
    next(err);
  }
}

module.exports = { search, autocomplete };
