const Place = require('../models/Place');
const Hotel = require('../models/Hotel');
const FoodSpot = require('../models/FoodSpot');
const User = require('../models/User');
const { haversineKm } = require('../services/budgetService');

async function listPlaces(req, res, next) {
  try {
    const { category, district, minRating, maxDistanceKm, lat, lng, sort } = req.query;
    const query = {};
    if (category) query.category = category;
    if (district) query.district = district;
    if (minRating) query['rating.avg'] = { $gte: Number(minRating) };

    let places = await Place.find(query).populate('district', 'name region').lean();

    if (lat && lng) {
      const origin = { lat: Number(lat), lng: Number(lng) };
      places = places.map((p) => ({ ...p, distanceKm: Math.round(haversineKm(origin, p.location) * 10) / 10 }));
      if (maxDistanceKm) places = places.filter((p) => p.distanceKm <= Number(maxDistanceKm));
    }

    if (sort === 'rating') places.sort((a, b) => (b.rating?.avg || 0) - (a.rating?.avg || 0));
    if (sort === 'distance' && lat && lng) places.sort((a, b) => a.distanceKm - b.distanceKm);

    res.json({ count: places.length, results: places });
  } catch (err) {
    next(err);
  }
}

async function getPlaceProfile(req, res, next) {
  try {
    const place = await Place.findById(req.params.id).populate('district', 'name region famousFood famousProducts');
    if (!place) return res.status(404).json({ error: 'Place not found' });

    // "Nearby recommendations" - spec section 23
    const [nearbyPlaces, nearbyHotels, nearbyFood] = await Promise.all([
      Place.find({ district: place.district._id, _id: { $ne: place._id } }).limit(6).lean(),
      Hotel.find({ district: place.district._id }).limit(6).lean(),
      FoodSpot.find({ district: place.district._id }).limit(6).lean()
    ]);

    res.json({ place, nearby: { places: nearbyPlaces, hotels: nearbyHotels, food: nearbyFood } });
  } catch (err) {
    next(err);
  }
}

async function saveFavourite(req, res, next) {
  try {
    const user = await User.findByIdAndUpdate(
      req.user.id,
      { $addToSet: { savedPlaces: req.params.id } },
      { new: true }
    ).select('savedPlaces');
    res.json({ savedPlaces: user.savedPlaces });
  } catch (err) {
    next(err);
  }
}

module.exports = { listPlaces, getPlaceProfile, saveFavourite };
