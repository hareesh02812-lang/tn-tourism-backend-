// All prices/timings here are illustrative starting data marked "estimated" -
// replace with verified data as you onboard real content per spec section 25.

const districts = [
  {
    name: 'Chennai',
    region: 'North',
    center: { lat: 13.0827, lng: 80.2707 },
    famousFor: ['heritage', 'beaches', 'culture'],
    famousFood: ['Chettinad chicken', 'filter coffee', 'Madras mutton curry'],
    famousProducts: ['silk sarees', 'leather goods'],
    description: 'Capital city, gateway to Tamil Nadu, home to Marina Beach and colonial-era landmarks.'
  },
  {
    name: 'Madurai',
    region: 'South',
    center: { lat: 9.9252, lng: 78.1198 },
    famousFor: ['temple', 'heritage', 'culture'],
    famousFood: ['Jigarthanda', 'Madurai idli'],
    famousProducts: ['Sungudi sarees'],
    description: 'Temple city on the Vaigai river, one of the oldest continuously inhabited cities in India.'
  },
  {
    name: 'The Nilgiris',
    region: 'West',
    center: { lat: 11.4102, lng: 76.6950 },
    famousFor: ['mountain', 'nature', 'trekking'],
    famousFood: ['Nilgiri tea', 'homemade chocolate'],
    famousProducts: ['tea', 'eucalyptus oil'],
    description: 'Hill district home to Ooty and Coonoor, in the Western Ghats.'
  },
  {
    name: 'Dindigul',
    region: 'South',
    center: { lat: 10.3624, lng: 77.9695 },
    famousFor: ['mountain', 'nature'],
    famousFood: ['Dindigul biryani'],
    famousProducts: ['locks'],
    description: 'Home to the hill station Kodaikanal.'
  },
  {
    name: 'Ramanathapuram',
    region: 'South',
    center: { lat: 9.3639, lng: 78.8395 },
    famousFor: ['temple', 'beach'],
    famousFood: ['seafood'],
    famousProducts: ['pearls', 'sea shells'],
    description: 'Coastal district, home to the Rameswaram temple town.'
  },
  {
    name: 'Kanyakumari',
    region: 'South',
    center: { lat: 8.0883, lng: 77.5385 },
    famousFor: ['beach', 'viewpoint', 'culture'],
    famousFood: ['seafood', 'banana chips'],
    famousProducts: ['handicrafts', 'sea shell items'],
    description: "India's southernmost tip, where three seas meet."
  }
];

// Places reference districts by index into the array above (resolved in seed.js)
const places = [
  {
    districtIndex: 0,
    name: 'Marina Beach',
    location: { lat: 13.0500, lng: 80.2824 },
    category: ['beach', 'family', 'photography'],
    shortDescription: "One of the world's longest urban beaches, a Chennai landmark.",
    history: 'Developed in the late 19th century under Governor Mountstuart Elphinstone Grant Duff.',
    importantFeatures: ['Lighthouse', 'Anna Memorial', 'long promenade'],
    visitingInfo: { openTime: '00:00', closeTime: '23:59', recommendedDurationHrs: 2, entryFeeINR: 0, dataQuality: 'estimated' },
    bestTimeToVisit: { morning: 'Good for a walk and sunrise', afternoon: 'Hot, less comfortable', evening: 'Best time - cooler, lively' },
    avgVisitCostINR: { low: 100, mid: 300, high: 800, dataQuality: 'estimated' },
    tags: ['beach', 'sunrise', 'chennai']
  },
  {
    districtIndex: 1,
    name: 'Meenakshi Amman Temple',
    location: { lat: 9.9195, lng: 78.1193 },
    category: ['temple', 'history', 'heritage', 'culture'],
    shortDescription: 'Historic Dravidian-style temple complex dedicated to Meenakshi and Sundareswarar, famed for its painted gopurams.',
    history: 'Present structure largely built during the Nayak dynasty in the 16th-17th centuries, on a much older temple site.',
    culturalSignificance: 'One of the most important Shaivite/Shaktha pilgrimage sites in South India.',
    importantFeatures: ['1000-pillar hall', 'painted gopurams', 'Golden Lotus tank'],
    visitingInfo: { openTime: '05:00', closeTime: '21:30', recommendedDurationHrs: 3, entryFeeINR: 0, dataQuality: 'estimated' },
    bestTimeToVisit: { morning: 'Best for rituals and fewer crowds', afternoon: 'Temple closes midday for a few hours', evening: 'Good for the evening deity procession' },
    avgVisitCostINR: { low: 50, mid: 200, high: 500, dataQuality: 'estimated' },
    tags: ['temple', 'madurai', 'heritage', 'dravidian architecture']
  },
  {
    districtIndex: 2,
    name: 'Ooty Botanical Garden & Doddabetta Peak',
    location: { lat: 11.4064, lng: 76.6932 },
    category: ['nature', 'mountain', 'family', 'photography'],
    shortDescription: 'Colonial-era botanical garden and the Nilgiris\' highest peak, both classic Ooty stops.',
    importantFeatures: ['Italian-style terrace garden', 'fossil tree trunk', 'Doddabetta viewpoint & telescope house'],
    visitingInfo: { openTime: '07:00', closeTime: '18:30', recommendedDurationHrs: 3, entryFeeINR: 50, dataQuality: 'estimated' },
    bestTimeToVisit: { morning: 'Clear skies, best visibility from Doddabetta', afternoon: 'Can get misty', evening: 'Chilly, garden closes early' },
    avgVisitCostINR: { low: 300, mid: 700, high: 1500, dataQuality: 'estimated' },
    tags: ['ooty', 'nilgiris', 'hill station', 'garden']
  },
  {
    districtIndex: 3,
    name: 'Kodaikanal Lake & Pillar Rocks',
    location: { lat: 10.2381, lng: 77.4892 },
    category: ['nature', 'mountain', 'trekking', 'viewpoint', 'family'],
    shortDescription: 'Star-shaped artificial lake and the dramatic 400-ft granite Pillar Rocks viewpoint above Kodaikanal.',
    importantFeatures: ['boating on the lake', 'Pillar Rocks viewpoint', 'Coaker\'s Walk'],
    visitingInfo: { openTime: '06:00', closeTime: '18:00', recommendedDurationHrs: 4, entryFeeINR: 30, dataQuality: 'estimated' },
    bestTimeToVisit: { morning: 'Best visibility before clouds roll in', afternoon: 'Good for boating', evening: 'Sunset from Coaker\'s Walk' },
    avgVisitCostINR: { low: 400, mid: 900, high: 2000, dataQuality: 'estimated' },
    tags: ['kodaikanal', 'hill station', 'lake', 'trekking']
  },
  {
    districtIndex: 4,
    name: 'Ramanathaswamy Temple, Rameswaram',
    location: { lat: 9.2882, lng: 79.3129 },
    category: ['temple', 'history', 'heritage', 'beach'],
    shortDescription: 'One of the twelve Jyotirlinga temples, famous for its long pillared corridors, on the island town of Rameswaram.',
    culturalSignificance: 'Major stop on the Char Dham pilgrimage circuit; linked to the Ramayana.',
    importantFeatures: ['longest temple corridor in India', '22 sacred wells (theerthams)'],
    visitingInfo: { openTime: '05:00', closeTime: '21:00', recommendedDurationHrs: 3, entryFeeINR: 0, dataQuality: 'estimated' },
    bestTimeToVisit: { morning: 'Best for the ritual bathing sequence', afternoon: 'Temple closes for a few hours', evening: 'Good for Dhanushkodi sunset nearby' },
    avgVisitCostINR: { low: 200, mid: 600, high: 1500, dataQuality: 'estimated' },
    tags: ['rameswaram', 'temple', 'pilgrimage', 'jyotirlinga']
  },
  {
    districtIndex: 5,
    name: 'Vivekananda Rock Memorial, Kanyakumari',
    location: { lat: 8.0778, lng: 77.5546 },
    category: ['viewpoint', 'culture', 'beach', 'photography'],
    shortDescription: 'Memorial on a rock island off India\'s southernmost tip, reached by ferry, where three seas meet.',
    importantFeatures: ['ferry ride', 'Thiruvalluvar Statue nearby', 'sunrise/sunset viewpoint'],
    visitingInfo: { openTime: '07:00', closeTime: '17:00', recommendedDurationHrs: 2, entryFeeINR: 50, dataQuality: 'estimated' },
    bestTimeToVisit: { morning: 'Famous for sunrise', afternoon: 'Ferry queues can be long', evening: 'Good for sunset over the sea' },
    avgVisitCostINR: { low: 200, mid: 500, high: 1200, dataQuality: 'estimated' },
    tags: ['kanyakumari', 'sunrise', 'sunset', 'ferry']
  }
];

const hotels = [
  { districtIndex: 0, name: 'Marina Budget Inn', tier: 'budget', pricePerNightINR: { low: 900, high: 1400 }, amenities: ['AC', 'wifi'] },
  { districtIndex: 0, name: 'Chennai Central Suites', tier: 'moderate', pricePerNightINR: { low: 2500, high: 4000 }, amenities: ['AC', 'wifi', 'breakfast'] },
  { districtIndex: 1, name: 'Meenakshi Heritage Stay', tier: 'moderate', pricePerNightINR: { low: 1800, high: 3200 }, amenities: ['AC', 'temple view'] },
  { districtIndex: 1, name: 'Madurai Backpackers Hostel', tier: 'budget', pricePerNightINR: { low: 500, high: 900 }, amenities: ['dorm beds', 'wifi'] },
  { districtIndex: 2, name: 'Nilgiris Hilltop Resort', tier: 'premium', pricePerNightINR: { low: 5500, high: 9000 }, amenities: ['fireplace', 'valley view', 'breakfast'] },
  { districtIndex: 2, name: 'Ooty Cottage Homestay', tier: 'moderate', pricePerNightINR: { low: 2200, high: 3500 }, amenities: ['hot water', 'garden'] },
  { districtIndex: 3, name: 'Kodai Lakeview Rooms', tier: 'moderate', pricePerNightINR: { low: 2000, high: 3400 }, amenities: ['lake view', 'wifi'] },
  { districtIndex: 4, name: 'Rameswaram Pilgrim Lodge', tier: 'budget', pricePerNightINR: { low: 700, high: 1100 }, amenities: ['AC', 'near temple'] },
  { districtIndex: 5, name: 'Kanyakumari Sea View Hotel', tier: 'moderate', pricePerNightINR: { low: 1900, high: 3000 }, amenities: ['sea view', 'AC'] }
];

const foodSpots = [
  { districtIndex: 0, name: 'Murugan Idli Shop', specialties: ['idli', 'filter coffee'], vegType: 'veg', avgMealCostINR: { low: 100, high: 250 } },
  { districtIndex: 1, name: 'Sri Sabarees Jigarthanda', specialties: ['Jigarthanda'], vegType: 'both', avgMealCostINR: { low: 50, high: 150 } },
  { districtIndex: 2, name: 'Nilgiris Homemade Chocolates & Cafe', specialties: ['chocolate', 'tea'], vegType: 'veg', avgMealCostINR: { low: 150, high: 400 } },
  { districtIndex: 3, name: 'Kodai PT Road Food Street', specialties: ['hot chocolate', 'local snacks'], vegType: 'both', avgMealCostINR: { low: 100, high: 300 } },
  { districtIndex: 4, name: 'Rameswaram Seafood Corner', specialties: ['fish curry', 'prawns'], vegType: 'non_veg', avgMealCostINR: { low: 200, high: 500 } },
  { districtIndex: 5, name: 'Kanyakumari Beachside Diner', specialties: ['seafood thali'], vegType: 'both', avgMealCostINR: { low: 150, high: 400 } }
];

module.exports = { districts, places, hotels, foodSpots };
