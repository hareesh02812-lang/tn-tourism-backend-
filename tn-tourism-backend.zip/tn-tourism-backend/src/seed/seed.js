require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('../config/db');

const District = require('../models/District');
const Place = require('../models/Place');
const Hotel = require('../models/Hotel');
const FoodSpot = require('../models/FoodSpot');

const { districts, places, hotels, foodSpots } = require('./seedData');

async function run() {
  await connectDB();

  console.log('[seed] clearing existing collections...');
  await Promise.all([
    District.deleteMany({}),
    Place.deleteMany({}),
    Hotel.deleteMany({}),
    FoodSpot.deleteMany({})
  ]);

  console.log('[seed] inserting districts...');
  const createdDistricts = await District.insertMany(districts);

  console.log('[seed] inserting places...');
  const createdPlaces = await Place.insertMany(
    places.map((p) => {
      const { districtIndex, ...rest } = p;
      return { ...rest, district: createdDistricts[districtIndex]._id };
    })
  );

  console.log('[seed] inserting hotels...');
  await Hotel.insertMany(
    hotels.map((h) => {
      const { districtIndex, ...rest } = h;
      return { ...rest, district: createdDistricts[districtIndex]._id };
    })
  );

  console.log('[seed] inserting food spots...');
  await FoodSpot.insertMany(
    foodSpots.map((f) => {
      const { districtIndex, ...rest } = f;
      return { ...rest, district: createdDistricts[districtIndex]._id };
    })
  );

  console.log(`[seed] done: ${createdDistricts.length} districts, ${createdPlaces.length} places`);
  await mongoose.disconnect();
  process.exit(0);
}

run().catch((err) => {
  console.error('[seed] failed', err);
  process.exit(1);
});
