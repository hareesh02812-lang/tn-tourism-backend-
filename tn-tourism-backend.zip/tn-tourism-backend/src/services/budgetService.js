const Place = require('../models/Place');
const Hotel = require('../models/Hotel');
const FoodSpot = require('../models/FoodSpot');

/**
 * Rough per-km transport rates used when no live fare API is configured.
 * All figures are clearly "estimated" - see spec section 25 (Data Reliability).
 */
const TRANSPORT_RATE_PER_KM_INR = {
  bus: 1.2,
  train: 0.9,
  auto: 15,
  taxi: 20,
  rapido_bike: 8
};

function haversineKm(a, b) {
  const R = 6371;
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLng = ((b.lng - a.lng) * Math.PI) / 180;
  const lat1 = (a.lat * Math.PI) / 180;
  const lat2 = (b.lat * Math.PI) / 180;
  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

function pickHotelTierForBudget(hotelBudgetPerNight) {
  if (hotelBudgetPerNight <= 1200) return 'budget';
  if (hotelBudgetPerNight <= 3500) return 'moderate';
  return 'premium';
}

/**
 * Estimate the full cost breakdown for a trip to a single destination place.
 * This backs both:
 *  - POST /api/budget/calculate (explicit trip inputs)
 *  - the "enter a max budget, get destinations that fit" flow (see budgetController.suggestForBudget)
 */
async function estimateTripCost({ place, days, people, startLocation, transportMode = 'bus', hotelTierHint }) {
  // 1. Travel cost: distance-based estimate (straight-line * 1.3 road-factor) unless startLocation coords given
  let distanceKm = 150; // fallback assumption when we don't know the starting point
  if (startLocation && startLocation.lat && startLocation.lng) {
    distanceKm = haversineKm(startLocation, place.location) * 1.3;
  }
  const ratePerKm = TRANSPORT_RATE_PER_KM_INR[transportMode] || TRANSPORT_RATE_PER_KM_INR.bus;
  const travelINR = Math.round(distanceKm * ratePerKm * 2 * people); // round trip, per person

  // 2. Hotel cost: pick hotels near the place matching tier hint (or mid-range default)
  const hotelQuery = { district: place.district };
  if (hotelTierHint) hotelQuery.tier = hotelTierHint;
  let hotels = await Hotel.find(hotelQuery).limit(5).lean();
  if (hotels.length === 0) hotels = await Hotel.find({ district: place.district }).limit(5).lean();

  const nights = Math.max(days - 1, days >= 1 ? 1 : 0);
  const avgHotelPerNight = hotels.length
    ? hotels.reduce((sum, h) => sum + (h.pricePerNightINR.low + h.pricePerNightINR.high) / 2, 0) / hotels.length
    : 1500; // fallback estimate
  const roomsNeeded = Math.ceil(people / 2);
  const hotelINR = Math.round(avgHotelPerNight * nights * roomsNeeded);

  // 3. Food cost
  const foodSpots = await FoodSpot.find({ district: place.district }).limit(5).lean();
  const avgMealCost = foodSpots.length
    ? foodSpots.reduce((sum, f) => sum + ((f.avgMealCostINR?.low || 150) + (f.avgMealCostINR?.high || 300)) / 2, 0) /
      foodSpots.length
    : 250;
  const mealsPerDay = 3;
  const foodINR = Math.round(avgMealCost * mealsPerDay * days * people);

  // 4. Attraction / entry-ticket cost
  const entryFee = place.visitingInfo?.entryFeeINR || 0;
  const attractionsINR = entryFee * people;

  // 5. Other estimated expenses (local transport at destination, misc, guides) - heuristic 10% of subtotal
  const subtotal = travelINR + hotelINR + foodINR + attractionsINR;
  const otherINR = Math.round(subtotal * 0.1);

  const totalINR = travelINR + hotelINR + foodINR + attractionsINR + otherINR;

  return {
    place: { id: place._id, name: place.name },
    days,
    people,
    breakdown: {
      travelINR,
      hotelINR,
      foodINR,
      attractionsINR,
      otherINR,
      totalINR
    },
    dataQuality: 'estimated', // per spec section 25 - never claim these are exact live prices
    note:
      'All figures are estimated from typical local rates and are not live prices. Connect GOOGLE_MAPS_API_KEY for live distance/fare data.'
  };
}

/**
 * Given only a max budget (+ optional days/people/start), recommend destinations that fit,
 * plus a slightly cheaper and slightly more expensive alternative (spec section 6 example).
 */
async function suggestDestinationsForBudget({ maxBudgetINR, days = 1, people = 1, startLocation, themes }) {
  const query = {};
  if (themes && themes.length) query.category = { $in: themes };

  const candidates = await Place.find(query).limit(40).lean();
  const hotelTierHint = pickHotelTierForBudget((maxBudgetINR * 0.3) / Math.max(days - 1, 1));

  const estimates = [];
  for (const place of candidates) {
    const est = await estimateTripCost({ place, days, people, startLocation, hotelTierHint });
    estimates.push(est);
  }

  estimates.sort((a, b) => a.breakdown.totalINR - b.breakdown.totalINR);

  const withinBudget = estimates.filter((e) => e.breakdown.totalINR <= maxBudgetINR);
  const best = withinBudget[withinBudget.length - 1] || estimates[0] || null;

  let cheaper = null;
  let pricier = null;
  if (best) {
    const idx = estimates.findIndex((e) => e.place.id.toString() === best.place.id.toString());
    cheaper = estimates.slice(0, idx).reverse().find((e) => e.breakdown.totalINR < best.breakdown.totalINR) || null;
    pricier = estimates.slice(idx + 1).find((e) => e.breakdown.totalINR > best.breakdown.totalINR) || null;
  }

  return {
    maxBudgetINR,
    recommended: best,
    cheaperAlternative: cheaper,
    pricierAlternative: pricier,
    allWithinBudgetCount: withinBudget.length
  };
}

module.exports = { estimateTripCost, suggestDestinationsForBudget, haversineKm, pickHotelTierForBudget };
