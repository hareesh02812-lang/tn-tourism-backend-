const fetch = require('node-fetch');

/**
 * Fetches live weather from OpenWeatherMap if OPENWEATHER_API_KEY is set.
 * If it's not set, returns a clearly-labelled "not currently available" response
 * instead of inventing weather data (spec section 25 forbids inventing weather).
 */
async function getLiveWeather({ lat, lng }) {
  const key = process.env.OPENWEATHER_API_KEY;
  if (!key) {
    return {
      available: false,
      reason: 'OPENWEATHER_API_KEY not configured',
      dataQuality: 'not_available'
    };
  }

  const url = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lng}&units=metric&appid=${key}`;
  const res = await fetch(url);
  if (!res.ok) {
    return { available: false, reason: `Weather API error (${res.status})`, dataQuality: 'not_available' };
  }
  const data = await res.json();

  return {
    available: true,
    dataQuality: 'live',
    temperatureC: data.main?.temp,
    feelsLikeC: data.main?.feels_like,
    condition: data.weather?.[0]?.description,
    humidityPct: data.main?.humidity,
    windSpeedMs: data.wind?.speed,
    rainProbabilityPct: null, // requires One Call API (paid tier) - see forecast() below
    fetchedAt: new Date().toISOString()
  };
}

/** Optional: 5-day/3-hour forecast, also gated behind the same API key. */
async function getForecast({ lat, lng }) {
  const key = process.env.OPENWEATHER_API_KEY;
  if (!key) {
    return { available: false, reason: 'OPENWEATHER_API_KEY not configured', dataQuality: 'not_available' };
  }
  const url = `https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lng}&units=metric&appid=${key}`;
  const res = await fetch(url);
  if (!res.ok) {
    return { available: false, reason: `Weather API error (${res.status})`, dataQuality: 'not_available' };
  }
  const data = await res.json();
  const list = (data.list || []).slice(0, 8).map((entry) => ({
    time: entry.dt_txt,
    temperatureC: entry.main.temp,
    condition: entry.weather?.[0]?.description,
    rainProbabilityPct: Math.round((entry.pop || 0) * 100)
  }));
  return { available: true, dataQuality: 'live', forecast: list };
}

module.exports = { getLiveWeather, getForecast };
