const router = require('express').Router();
const District = require('../models/District');
const Place = require('../models/Place');

router.get('/', async (req, res, next) => {
  try {
    const districts = await District.find().sort('name');
    res.json(districts);
  } catch (err) { next(err); }
});

router.get('/:id', async (req, res, next) => {
  try {
    const district = await District.findById(req.params.id);
    if (!district) return res.status(404).json({ error: 'District not found' });
    const places = await Place.find({ district: district._id });
    res.json({ district, places });
  } catch (err) { next(err); }
});

module.exports = router;
