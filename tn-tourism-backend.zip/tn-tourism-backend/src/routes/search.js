const router = require('express').Router();
const { search, autocomplete } = require('../controllers/searchController');

router.get('/', search);
router.get('/autocomplete', autocomplete);

module.exports = router;
