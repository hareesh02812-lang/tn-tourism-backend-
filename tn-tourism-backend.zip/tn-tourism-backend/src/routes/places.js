const router = require('express').Router();
const { listPlaces, getPlaceProfile, saveFavourite } = require('../controllers/placeController');
const { requireAuth } = require('../middleware/auth');

router.get('/', listPlaces);
router.get('/:id', getPlaceProfile);
router.post('/:id/save', requireAuth, saveFavourite);

module.exports = router;
