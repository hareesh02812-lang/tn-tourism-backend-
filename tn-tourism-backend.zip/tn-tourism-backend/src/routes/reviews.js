const router = require('express').Router();
const { createReview, approveReview, listReviewsForTarget } = require('../controllers/reviewController');
const { requireAuth } = require('../middleware/auth');

router.post('/', requireAuth, createReview);
router.patch('/:id/approve', requireAuth, approveReview);
router.get('/:targetType/:targetId', listReviewsForTarget);

module.exports = router;
