const router = require('express').Router();
const FoodSpot = require('../models/FoodSpot');

router.get('/', async (req, res, next) => {
  try {
    const { district, vegType } = req.query;
    const query = {};
    if (district) query.district = district;
    if (vegType) query.vegType = vegType;
    const spots = await FoodSpot.find(query).sort('-rating.avg');
    res.json({ count: spots.length, results: spots });
  } catch (err) { next(err); }
});

module.exports = router;
