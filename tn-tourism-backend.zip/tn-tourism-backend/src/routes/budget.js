const router = require('express').Router();
const { calculate, suggest } = require('../controllers/budgetController');

router.post('/calculate', calculate);
router.post('/suggest', suggest);

module.exports = router;
