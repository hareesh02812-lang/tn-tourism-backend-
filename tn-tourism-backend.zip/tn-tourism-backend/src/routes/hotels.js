const router = require('express').Router();
const Hotel = require('../models/Hotel');

router.get('/', async (req, res, next) => {
  try {
    const { district, tier, maxPrice } = req.query;
    const query = {};
    if (district) query.district = district;
    if (tier) query.tier = tier;
    if (maxPrice) query['pricePerNightINR.low'] = { $lte: Number(maxPrice) };
    const hotels = await Hotel.find(query).sort('-rating.avg');
    res.json({ count: hotels.length, results: hotels });
  } catch (err) { next(err); }
});

router.get('/:id', async (req, res, next) => {
  try {
    const hotel = await Hotel.findById(req.params.id).populate('nearPlace', 'name');
    if (!hotel) return res.status(404).json({ error: 'Hotel not found' });
    res.json(hotel);
  } catch (err) { next(err); }
});

module.exports = router;
