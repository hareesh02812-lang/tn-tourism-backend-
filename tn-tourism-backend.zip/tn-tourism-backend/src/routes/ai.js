const router = require('express').Router();
const { itinerary } = require('../controllers/aiController');

router.post('/itinerary', itinerary);

module.exports = router;
