const router = require('express').Router();
const { current, forecast } = require('../controllers/weatherController');

router.get('/', current);
router.get('/forecast', forecast);

module.exports = router;
