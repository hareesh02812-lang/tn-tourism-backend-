const mongoose = require('mongoose');

const TripSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }, // optional: allow anonymous planning
    title: String,
    startLocation: String,
    days: { type: Number, required: true },
    people: { type: Number, required: true, default: 1 },
    totalBudgetINR: Number,
    itinerary: [
      {
        day: Number,
        place: { type: mongoose.Schema.Types.ObjectId, ref: 'Place' },
        placeName: String, // denormalized so itinerary reads fine even if place isn't in DB
        arriveBy: String,
        activities: [String],
        estCostINR: Number
      }
    ],
    costBreakdown: {
      travelINR: Number,
      hotelINR: Number,
      foodINR: Number,
      attractionsINR: Number,
      otherINR: Number,
      totalINR: Number
    },
    generatedBy: { type: String, enum: ['rule_engine', 'claude'], default: 'rule_engine' }
  },
  { timestamps: true }
);

module.exports = mongoose.model('Trip', TripSchema);
