const mongoose = require('mongoose');

const DistrictSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, unique: true, trim: true },
    nameLocal: {
      ta: String,
      hi: String
    },
    region: { type: String, enum: ['North', 'South', 'East', 'West', 'Central', 'Delta'], required: true },
    center: {
      lat: { type: Number, required: true },
      lng: { type: Number, required: true }
    },
    famousFor: [String], // e.g. ["temples", "hill station", "beach"]
    famousFood: [String],
    famousProducts: [String],
    description: String
  },
  { timestamps: true }
);

module.exports = mongoose.model('District', DistrictSchema);
