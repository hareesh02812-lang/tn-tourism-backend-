const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const UserSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    passwordHash: { type: String, required: true },
    preferredLanguage: { type: String, enum: ['en', 'ta', 'hi'], default: 'en' },
    savedPlaces: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Place' }],
    savedHotels: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Hotel' }],
    savedTrips: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Trip' }]
  },
  { timestamps: true }
);

UserSchema.methods.comparePassword = function (candidate) {
  return bcrypt.compare(candidate, this.passwordHash);
};

UserSchema.statics.hashPassword = function (plain) {
  return bcrypt.hash(plain, 10);
};

module.exports = mongoose.model('User', UserSchema);
