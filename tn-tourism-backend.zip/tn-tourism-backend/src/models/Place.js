const mongoose = require('mongoose');

/**
 * Every numeric estimate on this model (avgVisitCostINR, crowd levels, etc.)
 * is tagged with a `dataQuality` so the API/UI can be honest about what's
 * verified vs. estimated vs. user-submitted (spec section 25: Data Reliability).
 */
const DATA_QUALITY = ['verified', 'live', 'estimated', 'user_generated'];

const CrowdSlotSchema = new mongoose.Schema(
  {
    day: { type: String, enum: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'], required: true },
    timeOfDay: { type: String, enum: ['morning', 'afternoon', 'evening'], required: true },
    level: { type: String, enum: ['low', 'moderate', 'high'], required: true },
    source: { type: String, enum: DATA_QUALITY, default: 'estimated' }
  },
  { _id: false }
);

const PlaceSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, index: true },
    nameLocal: { ta: String, hi: String },
    district: { type: mongoose.Schema.Types.ObjectId, ref: 'District', required: true },
    location: {
      lat: { type: Number, required: true },
      lng: { type: Number, required: true }
    },
    category: {
      type: [String],
      enum: [
        'temple', 'history', 'heritage', 'nature', 'trekking', 'wildlife',
        'beach', 'mountain', 'adventure', 'family', 'photography',
        'food', 'culture', 'waterfall', 'viewpoint'
      ],
      required: true
    },
    shortDescription: { type: String, required: true },
    history: String,
    culturalSignificance: String,
    importantFeatures: [String],
    photos: [{ url: String, caption: String }],

    visitingInfo: {
      openTime: String, // e.g. "06:00"
      closeTime: String, // e.g. "20:00"
      bestMonths: [String],
      recommendedDurationHrs: Number,
      entryFeeINR: { type: Number, default: 0 },
      dataQuality: { type: String, enum: DATA_QUALITY, default: 'estimated' }
    },

    bestTimeToVisit: {
      morning: String,
      afternoon: String,
      evening: String
    },

    crowdPattern: [CrowdSlotSchema],

    avgVisitCostINR: {
      // used by the budget calculator as a baseline per-person figure
      low: Number,
      mid: Number,
      high: Number,
      dataQuality: { type: String, enum: DATA_QUALITY, default: 'estimated' }
    },

    tags: [String], // free-text theme tags for search/filters
    rating: { avg: { type: Number, default: 0 }, count: { type: Number, default: 0 } }
  },
  { timestamps: true }
);

PlaceSchema.index({ name: 'text', shortDescription: 'text', tags: 'text' });

module.exports = mongoose.model('Place', PlaceSchema);
module.exports.DATA_QUALITY = DATA_QUALITY;
