const mongoose = require('mongoose');

const ReviewSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    targetType: { type: String, enum: ['place', 'hotel', 'foodSpot'], required: true },
    target: { type: mongoose.Schema.Types.ObjectId, required: true, refPath: 'targetType_model' },
    targetType_model: { type: String }, // set programmatically to 'Place' | 'Hotel' | 'FoodSpot'
    stars: { type: Number, min: 1, max: 5, required: true },
    text: String,
    photos: [String],
    status: { type: String, enum: ['pending', 'approved', 'rejected'], default: 'pending' }
  },
  { timestamps: true }
);

module.exports = mongoose.model('Review', ReviewSchema);
