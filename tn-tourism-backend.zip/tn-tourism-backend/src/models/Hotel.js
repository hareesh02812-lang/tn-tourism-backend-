const mongoose = require('mongoose');

const HotelSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, index: true },
    district: { type: mongoose.Schema.Types.ObjectId, ref: 'District', required: true },
    nearPlace: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Place' }],
    location: { lat: Number, lng: Number },
    tier: { type: String, enum: ['budget', 'moderate', 'premium'], required: true },
    pricePerNightINR: {
      low: { type: Number, required: true },
      high: { type: Number, required: true },
      dataQuality: { type: String, default: 'estimated' }
    },
    photos: [{ url: String, caption: String }],
    rating: { avg: { type: Number, default: 0 }, count: { type: Number, default: 0 } },
    contact: {
      phone: String,
      verified: { type: Boolean, default: false }
    },
    amenities: [String]
  },
  { timestamps: true }
);

HotelSchema.index({ name: 'text' });

module.exports = mongoose.model('Hotel', HotelSchema);
