const mongoose = require('mongoose');

const FoodSpotSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, index: true },
    district: { type: mongoose.Schema.Types.ObjectId, ref: 'District', required: true },
    nearPlace: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Place' }],
    specialties: [String],
    vegType: { type: String, enum: ['veg', 'non_veg', 'both'], default: 'both' },
    avgMealCostINR: {
      low: Number,
      high: Number,
      dataQuality: { type: String, default: 'estimated' }
    },
    rating: { avg: { type: Number, default: 0 }, count: { type: Number, default: 0 } }
  },
  { timestamps: true }
);

module.exports = mongoose.model('FoodSpot', FoodSpotSchema);
